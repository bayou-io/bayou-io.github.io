This directory contains resource files.
If a file is outdated, you may download it from the source and replace the file.
Or you may modify the file for your own reasons.

Files:


mime.types.txt
    source:
        http://svn.apache.org/viewvc/httpd/httpd/trunk/docs/conf/mime.types?view=co

public.suffix.txt
    source:
        https://publicsuffix.org/list/effective_tld_names.dat
