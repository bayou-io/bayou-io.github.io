/**
 * Some functional interfaces.
 */
package bayou.util.function;