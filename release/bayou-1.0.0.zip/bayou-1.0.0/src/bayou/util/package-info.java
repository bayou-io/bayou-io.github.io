/**
 * Miscellaneous types and utilities.
 */
package bayou.util;