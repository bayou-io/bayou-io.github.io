/**
 * For building html trees.
 */
package bayou.html;