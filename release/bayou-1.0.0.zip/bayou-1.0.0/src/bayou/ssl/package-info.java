/**
 * SSL support.
 */
package bayou.ssl;