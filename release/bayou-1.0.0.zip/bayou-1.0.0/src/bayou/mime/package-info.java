/**
 * MIME related utilities.
 */
package bayou.mime;