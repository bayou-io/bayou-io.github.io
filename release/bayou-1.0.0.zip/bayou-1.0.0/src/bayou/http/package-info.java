/**
 * Http server.
 */
package bayou.http;