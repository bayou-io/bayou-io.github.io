/**
 * Async programming model.
 */
package bayou.async;