/**
 * Async byte source/sink.
 */
package bayou.bytes;