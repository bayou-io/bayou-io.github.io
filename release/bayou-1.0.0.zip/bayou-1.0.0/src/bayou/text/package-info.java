/**
 * Utilities for texts.
 */
package bayou.text;