/**
 * Html form handling.
 */
package bayou.form;