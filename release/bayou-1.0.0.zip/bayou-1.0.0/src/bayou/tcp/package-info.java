/**
 * Non-blocking TCP server.
 */
package bayou.tcp;