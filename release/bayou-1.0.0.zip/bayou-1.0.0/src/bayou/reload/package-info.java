/**
 * Hot-reload support.
 */
package bayou.reload;