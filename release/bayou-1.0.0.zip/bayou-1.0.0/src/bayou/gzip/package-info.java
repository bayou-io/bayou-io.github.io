/**
 * GZIP related utils.
 */
package bayou.gzip;

// this deserves a separate package, since we'll probably add more gzip/gunzip stuff in future.