/**
 * Utilities for files.
 */
package bayou.file;