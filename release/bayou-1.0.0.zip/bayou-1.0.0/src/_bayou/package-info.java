/**
 * internal stuff. not publicized.
 */
package _bayou;