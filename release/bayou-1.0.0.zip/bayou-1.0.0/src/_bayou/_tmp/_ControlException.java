package _bayou._tmp;

public class _ControlException extends Exception
{
    public _ControlException()
    {
        super(null, null, false, false);
    }
    public _ControlException(String msg)
    {
        super(msg, null, false, false);
    }
}
